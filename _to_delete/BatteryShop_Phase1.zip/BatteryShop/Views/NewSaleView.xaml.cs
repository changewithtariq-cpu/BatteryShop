using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using BatteryShop.Data;
using BatteryShop.Helpers;
using BatteryShop.Models;
using BatteryShop.Printing;

namespace BatteryShop.Views;

public partial class NewSaleView : UserControl
{
    private readonly ObservableCollection<SaleLine> _lines = new();
    private readonly ObservableCollection<ExchangeLine> _exchanges = new();
    private Customer _walkIn;
    private bool _paidFollowsTotal = true;   // "Paid now" follows the bill total until the user types a different amount
    private bool _settingPaid;

    public NewSaleView()
    {
        InitializeComponent();
        LinesGrid.ItemsSource = _lines;
        ExchangeGrid.ItemsSource = _exchanges;
        MethodBox.ItemsSource = PaymentMethods.All;
        MethodBox.SelectedIndex = 0;
        PreviewKeyDown += OnKey;
        Loaded += (_, _) => { if (CustomerBox.ItemsSource == null) Init(); };
    }

    private void Init()
    {
        _walkIn = PartyRepo.GetWalkInCustomer();
        LoadCustomers(_walkIn?.Id);
        LoadUnits();
        UpdateTotals();
        SerialBox.Focus();
    }

    private void LoadCustomers(long? selectId)
    {
        var list = PartyRepo.GetCustomers();
        CustomerBox.ItemsSource = list;
        CustomerBox.SelectedItem = list.FirstOrDefault(c => c.Id == selectId);
    }

    private void LoadUnits()
    {
        UnitBox.ItemsSource = StockRepo.GetUnits(status: "InStock");
        UnitBox.SelectedItem = null;
        UnitBox.Text = "";
    }

    private void OnKey(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.F9) { SaveSale(print: true); e.Handled = true; }
    }

    // ================================================================ Customer
    private Customer SelectedCustomer => CustomerBox.SelectedItem as Customer;

    private void CustomerBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        var c = SelectedCustomer;
        if (c == null) { CustomerBalanceText.Text = ""; return; }
        if (c.IsWalkIn)
        {
            CustomerBalanceText.Text = "Cash sale";
            CustomerBalanceText.Foreground = (System.Windows.Media.Brush)FindResource("MutedBrush");
        }
        else
        {
            CustomerBalanceText.Text = "Old balance: " + UI.Rs(c.Balance);
            CustomerBalanceText.Foreground = (System.Windows.Media.Brush)FindResource(c.Balance > 0 ? "DangerBrush" : "SuccessBrush");
        }
        // Named customers often pay partly; walk-in must pay in full
        _paidFollowsTotal = true;
        UpdateTotals();
    }

    private void WalkIn_Click(object sender, RoutedEventArgs e)
        => CustomerBox.SelectedItem = ((IEnumerable<Customer>)CustomerBox.ItemsSource).FirstOrDefault(c => c.IsWalkIn);

    private void NewCustomer_Click(object sender, RoutedEventArgs e)
    {
        var name = UI.Prompt("New customer", "Customer name:");
        if (string.IsNullOrWhiteSpace(name)) return;
        var phone = UI.Prompt("New customer", $"Phone number for {name} (optional):");
        if (phone == null) return;
        UI.Run(() =>
        {
            var id = PartyRepo.SaveCustomer(new Customer { Name = name, Phone = phone });
            LoadCustomers(id);
        });
    }

    // ================================================================ Batteries
    private void SerialBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter) { AddSerial_Click(sender, e); e.Handled = true; }
    }

    private void AddSerial_Click(object sender, RoutedEventArgs e)
    {
        var serial = SerialBox.Text.Trim();
        if (serial.Length == 0) return;
        var unit = StockRepo.FindInStockBySerial(serial);
        if (unit == null)
        {
            UI.Info($"No battery with serial '{serial}' is in stock.\nCheck the number, or pick the battery from the list below.");
            SerialBox.SelectAll();
            return;
        }
        if (AddUnit(unit)) SerialBox.Text = "";
        SerialBox.Focus();
    }

    private void AddPicked_Click(object sender, RoutedEventArgs e)
    {
        if (UnitBox.SelectedItem is not BatteryUnit unit) { UI.Info("Pick a battery from the list first."); return; }
        if (AddUnit(unit)) { UnitBox.SelectedItem = null; UnitBox.Text = ""; }
    }

    private bool AddUnit(BatteryUnit unit)
    {
        if (_lines.Any(l => l.Unit.Id == unit.Id)) { UI.Info("This battery is already on the bill."); return false; }
        var line = new SaleLine
        {
            Unit = unit,
            UnitPrice = unit.SuggestedPrice,
            WarrantyMonths = unit.Condition == "New" ? unit.WarrantyMonths : 0
        };
        line.PropertyChanged += (_, _) => UpdateTotals();
        _lines.Add(line);
        UpdateTotals();
        return true;
    }

    private void RemoveLine_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as FrameworkElement)?.DataContext is SaleLine l) { _lines.Remove(l); UpdateTotals(); }
    }

    private void LinesGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        => Dispatcher.BeginInvoke(new Action(UpdateTotals), DispatcherPriority.Background);

    // ================================================================ Exchange
    private void AddExchange_Click(object sender, RoutedEventArgs e)
    {
        UI.Run(() =>
        {
            var value = UI.Money(ExValue.Text, "Exchange value");
            if (value <= 0) throw new AppException("Enter the value you are giving for the old battery.");
            _exchanges.Add(new ExchangeLine
            {
                Description = string.IsNullOrWhiteSpace(ExDesc.Text) ? "Old battery" : ExDesc.Text.Trim(),
                WeightKg = UI.Decimal(ExWeight.Text, "Weight"),
                ExchangeValue = value
            });
            ExDesc.Text = "Old battery";
            ExWeight.Text = ExValue.Text = "";
            UpdateTotals();
        });
    }

    private void RemoveExchange_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as FrameworkElement)?.DataContext is ExchangeLine x) { _exchanges.Remove(x); UpdateTotals(); }
    }

    // ================================================================ Totals
    private long Net => _lines.Sum(l => l.LineTotal) - UI.MoneyOrZero(DiscountBox.Text) - _exchanges.Sum(x => x.ExchangeValue);

    private void Amount_Changed(object sender, TextChangedEventArgs e)
    {
        if (IsInitialized && sender == PaidBox && !_settingPaid) _paidFollowsTotal = false;
        UpdateTotals();
    }

    private void FullPaid_Click(object sender, RoutedEventArgs e)
    {
        _paidFollowsTotal = true;
        UpdateTotals();
    }

    private void UpdateTotals()
    {
        if (!IsInitialized || NetText == null || PaidBox == null) return;
        var sub = _lines.Sum(l => l.LineTotal);
        var exchange = _exchanges.Sum(x => x.ExchangeValue);
        var net = Net;

        SubTotalText.Text = sub.ToString("N0");
        ExchangeText.Text = exchange > 0 ? "-" + exchange.ToString("N0") : "0";
        NetText.Text = UI.Rs(net);

        if (_paidFollowsTotal)
        {
            _settingPaid = true;
            PaidBox.Text = Math.Max(net, 0).ToString("N0");
            _settingPaid = false;
        }

        var paid = UI.MoneyOrZero(PaidBox.Text);
        var remaining = net - paid;
        RemainingText.Text = UI.Rs(remaining);
        PaymentTypeText.Text = net <= 0 ? "" : paid >= net ? "Full cash payment" : paid == 0 ? "Full credit (udhaar)" : "Partial payment";
    }

    // ================================================================ Save
    private void SavePrint_Click(object sender, RoutedEventArgs e) => SaveSale(print: true);
    private void Save_Click(object sender, RoutedEventArgs e) => SaveSale(print: false);

    private void SaveSale(bool print)
    {
        // Commit any cell the user is still typing in
        LinesGrid.CommitEdit(DataGridEditingUnit.Row, true);

        long saleId = 0;
        var ok = UI.Run(() =>
        {
            if (SelectedCustomer == null)
                throw new AppException("Please select a customer from the list (or click Walk-in / + New customer).");
            saleId = SaleRepo.SaveSale(SelectedCustomer.Id, _lines.ToList(), _exchanges.ToList(),
                UI.Money(DiscountBox.Text, "Discount"), UI.Money(PaidBox.Text, "Paid now"),
                MethodBox.SelectedItem as string, string.IsNullOrWhiteSpace(NotesBox.Text) ? null : NotesBox.Text.Trim());
        });
        if (!ok) return;

        var customerId = SelectedCustomer.Id;
        if (print)
        {
            var receipt = SaleRepo.GetReceipt(saleId);
            ReceiptPrinter.PrintOrPreview(ReceiptBuilder.BuildSaleReceipt(receipt), () => SaleRepo.MarkPrinted(saleId));
        }
        else
        {
            var s = SaleRepo.GetReceipt(saleId).Sale;
            UI.Info($"Sale {s.InvoiceNo} saved.\nTotal {UI.Rs(s.NetTotal)}, paid {UI.Rs(s.PaidAmount)}, remaining {UI.Rs(s.RemainingAmount)}.");
        }

        ClearBill();
        LoadCustomers(_walkIn?.Id);
        LoadUnits();
    }

    private void Clear_Click(object sender, RoutedEventArgs e)
    {
        if ((_lines.Count > 0 || _exchanges.Count > 0) && !UI.Confirm("Clear this bill?")) return;
        ClearBill();
        CustomerBox.SelectedItem = ((IEnumerable<Customer>)CustomerBox.ItemsSource)?.FirstOrDefault(c => c.IsWalkIn);
    }

    private void ClearBill()
    {
        _lines.Clear();
        _exchanges.Clear();
        DiscountBox.Text = "0";
        NotesBox.Text = "";
        MethodBox.SelectedIndex = 0;
        _paidFollowsTotal = true;
        UpdateTotals();
        SerialBox.Focus();
    }
}
